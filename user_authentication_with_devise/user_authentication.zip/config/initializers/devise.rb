Devise.setup do |config|
	config.secret_key = ENV["DEVISE_TOKEN_AUTH_SECRET_KEY"]
end