require "rails_helper"

RSpec.describe Movie, :type => :model do
	describe "Validations" do
		it "is valid with valid attributes"
		it "should have a title"
		it "should have a year"
		it "should have a plot"
	end
  
end